AFNANSAKHA HUB — RECREATED UI TEST PACKAGE
=============================================

This is a recreation of the UI shown in the supplied screenshots, adapted for
your OWN Roblox experience/testing environment.

Included:
- Scripts / Settings / History tabs
- Aimbot Circle toggle
- Aimbot Shoot Button toggle
- Remove Teammate Target toggle
- Circle Radius slider
- Circle Color selector
- Camera Target selector
- Aim Smoothness slider
- SAVE CHANGES button
- DataStore persistence
- Draggable UI
- RightShift open/close
- Mobile-friendly floating open button
- Training target aim system

SETUP
-----
1. Publish your Roblox experience.
2. In Workspace create a Folder named:
       TrainingTargets
3. Put your own NPC/dummy Models in that folder.
   Each target should have a Humanoid and preferably Head/HumanoidRootPart.
4. Create a Script in:
       ServerScriptService
   and paste AimAssistHubServer.lua into it.
5. Create a LocalScript in:
       StarterPlayer > StarterPlayerScripts
   and paste AimAssistHubClient.lua into it.
6. Press Play.

DATASTORE TESTING
-----------------
For Studio persistence:
Game Settings > Security > Enable Studio Access to API Services

DataStore saving only works for your own published experience.

CONTROLS
--------
Desktop:
RightShift = toggle the hub.

Mobile:
Use the floating ≡ button after closing the hub.

IMPORTANT
---------
The targeting code ONLY scans Workspace.TrainingTargets.
It is intended for testing mechanics in your own Roblox experience.

The "Aimbot Shoot Button" is a settings toggle. It is not connected to
arbitrary weapon remotes or external script execution.

The bottom "EXECUTE SELECTED TRAINING" button simply enables the training
assist. "TRAINING INFO" displays the target restriction.
