-- AimAssistHubClient.lua
-- Place in StarterPlayer > StarterPlayerScripts as a LocalScript.
-- Designed for your own Roblox experience/testing environment.
-- Targets are restricted to Workspace.TrainingTargets.

local Players = game:GetService("Players")
local UIS = game:GetService("UserInputService")
local RunService = game:GetService("RunService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")

local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")

local remotes = ReplicatedStorage:WaitForChild("AimAssistRemotes")
local saveRemote = remotes:WaitForChild("SaveSettings")
local loadRemote = remotes:WaitForChild("LoadSettings")

local DEFAULTS = {
	AimbotCircle = false,
	AimbotShootButton = false,
	RemoveTeammateTarget = true,
	CircleRadius = 100,
	CircleColor = "Cyan Neon",
	CameraTarget = "Head",
	Smoothness = 0.18,
}

local settings = table.clone(DEFAULTS)

local ok, saved = pcall(function()
	return loadRemote:InvokeServer()
end)
if ok and type(saved) == "table" then
	for k in pairs(DEFAULTS) do
		if saved[k] ~= nil then settings[k] = saved[k] end
	end
end

local colorMap = {
	["Cyan Neon"] = Color3.fromRGB(0, 230, 255),
	["White"] = Color3.fromRGB(245, 250, 255),
	["Red"] = Color3.fromRGB(255, 75, 75),
	["Green"] = Color3.fromRGB(80, 255, 120),
	["Yellow"] = Color3.fromRGB(255, 225, 70),
}

local gui = Instance.new("ScreenGui")
gui.Name = "AimAssistHub"
gui.ResetOnSpawn = false
gui.IgnoreGuiInset = true
gui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
gui.Parent = playerGui

local function corner(obj, radius)
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, radius or 6)
	c.Parent = obj
	return c
end

local function stroke(obj, color, thickness, transparency)
	local s = Instance.new("UIStroke")
	s.Color = color
	s.Thickness = thickness or 1
	s.Transparency = transparency or 0
	s.Parent = obj
	return s
end

-- Main window
local main = Instance.new("Frame")
main.Name = "Hub"
main.Size = UDim2.fromOffset(470, 390)
main.Position = UDim2.new(1, -490, 0.5, -195)
main.BackgroundColor3 = Color3.fromRGB(6, 20, 40)
main.BorderSizePixel = 0
main.Parent = gui
corner(main, 10)
stroke(main, Color3.fromRGB(0, 150, 255), 2, 0.1)

-- Drag support
local dragging, dragStart, startPos
main.InputBegan:Connect(function(input)
	if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
		dragging = true
		dragStart = input.Position
		startPos = main.Position
	end
end)
UIS.InputChanged:Connect(function(input)
	if dragging and (input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch) then
		local delta = input.Position - dragStart
		main.Position = UDim2.new(
			startPos.X.Scale, startPos.X.Offset + delta.X,
			startPos.Y.Scale, startPos.Y.Offset + delta.Y
		)
	end
end)
UIS.InputEnded:Connect(function(input)
	if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
		dragging = false
	end
end)

local title = Instance.new("TextLabel")
title.Size = UDim2.new(1, -55, 0, 42)
title.Position = UDim2.fromOffset(15, 4)
title.BackgroundTransparency = 1
title.Text = "AFNANSAKHA HUB"
title.TextColor3 = Color3.fromRGB(0, 195, 255)
title.Font = Enum.Font.GothamBold
title.TextSize = 17
title.TextXAlignment = Enum.TextXAlignment.Left
title.Parent = main

local close = Instance.new("TextButton")
close.Size = UDim2.fromOffset(32, 32)
close.Position = UDim2.new(1, -39, 0, 6)
close.BackgroundTransparency = 1
close.Text = "X"
close.TextColor3 = Color3.fromRGB(0, 175, 245)
close.Font = Enum.Font.GothamBold
close.TextSize = 17
close.Parent = main
close.Activated:Connect(function() main.Visible = false end)

local tabs = Instance.new("Frame")
tabs.Size = UDim2.new(1, -20, 0, 39)
tabs.Position = UDim2.fromOffset(10, 45)
tabs.BackgroundTransparency = 1
tabs.Parent = main

local content = Instance.new("ScrollingFrame")
content.Size = UDim2.new(1, -20, 1, -140)
content.Position = UDim2.fromOffset(10, 89)
content.BackgroundTransparency = 1
content.BorderSizePixel = 0
content.ScrollBarThickness = 3
content.AutomaticCanvasSize = Enum.AutomaticSize.Y
content.CanvasSize = UDim2.new()
content.Parent = main

local list = Instance.new("UIListLayout")
list.Padding = UDim.new(0, 6)
list.Parent = content

local bottom = Instance.new("Frame")
bottom.Size = UDim2.new(1, -20, 0, 40)
bottom.Position = UDim2.new(0, 10, 1, -48)
bottom.BackgroundTransparency = 1
bottom.Parent = main

local execute = Instance.new("TextButton")
execute.Size = UDim2.new(0.74, -4, 1, 0)
execute.BackgroundColor3 = Color3.fromRGB(0, 65, 220)
execute.Text = "EXECUTE SELECTED TRAINING"
execute.TextColor3 = Color3.fromRGB(210, 230, 255)
execute.Font = Enum.Font.GothamBold
execute.TextSize = 10
execute.Parent = bottom
corner(execute, 5)
execute.Activated:Connect(function()
	-- Safe equivalent for an own-game UI: toggles the configured training assist.
	settings.AimbotCircle = true
	circle.Visible = true
	execute.Text = "TRAINING ASSIST ENABLED"
	task.delay(1.4, function()
		if execute.Parent then execute.Text = "EXECUTE SELECTED TRAINING" end
	end)
end)

local paste = Instance.new("TextButton")
paste.Size = UDim2.new(0.26, -4, 1, 0)
paste.Position = UDim2.new(0.74, 4, 0, 0)
paste.BackgroundColor3 = Color3.fromRGB(8, 38, 75)
paste.Text = "TRAINING INFO"
paste.TextColor3 = Color3.fromRGB(0, 185, 255)
paste.Font = Enum.Font.GothamBold
paste.TextSize = 10
paste.Parent = bottom
corner(paste, 5)
paste.Activated:Connect(function()
	-- No external script execution is performed.
	paste.Text = "TARGETS: NPCs ONLY"
	task.delay(1.5, function()
		if paste.Parent then paste.Text = "TRAINING INFO" end
	end)
end)

local function makeTab(text, x)
	local b = Instance.new("TextButton")
	b.Size = UDim2.new(1/3, -5, 1, 0)
	b.Position = UDim2.new(x, 0, 0, 0)
	b.BackgroundColor3 = Color3.fromRGB(9, 33, 63)
	b.BorderSizePixel = 0
	b.Text = text:upper()
	b.TextColor3 = Color3.fromRGB(165, 195, 225)
	b.Font = Enum.Font.GothamBold
	b.TextSize = 10
	b.Parent = tabs
	corner(b, 5)
	return b
end

local scriptsTab = makeTab("Scripts", 0)
local settingsTab = makeTab("Settings", 1/3)
local historyTab = makeTab("History", 2/3)

-- Aim circle
circle = Instance.new("Frame")
circle.Name = "AimCircle"
circle.AnchorPoint = Vector2.new(0.5, 0.5)
circle.Position = UDim2.fromScale(0.5, 0.5)
circle.BackgroundTransparency = 1
circle.Parent = gui
corner(circle, 999)
local circleStroke = stroke(circle, colorMap[settings.CircleColor], 2, 0.05)

local function refreshCircle()
	circle.Size = UDim2.fromOffset(settings.CircleRadius * 2, settings.CircleRadius * 2)
	circleStroke.Color = colorMap[settings.CircleColor] or colorMap["Cyan Neon"]
	circle.Visible = settings.AimbotCircle
end

local function clear()
	for _, child in ipairs(content:GetChildren()) do
		if child ~= list then child:Destroy() end
	end
end

local function rowBase(height)
	local row = Instance.new("Frame")
	row.Size = UDim2.new(1, -5, 0, height)
	row.BackgroundColor3 = Color3.fromRGB(9, 31, 58)
	row.BorderSizePixel = 0
	row.Parent = content
	corner(row, 6)
	return row
end

local function makeToggle(labelText, key)
	local row = rowBase(43)

	local label = Instance.new("TextLabel")
	label.Size = UDim2.new(1, -78, 1, 0)
	label.Position = UDim2.fromOffset(12, 0)
	label.BackgroundTransparency = 1
	label.TextColor3 = Color3.fromRGB(205, 220, 235)
	label.Font = Enum.Font.Gotham
	label.TextSize = 11
	label.TextXAlignment = Enum.TextXAlignment.Left
	label.Parent = row

	local sw = Instance.new("TextButton")
	sw.Size = UDim2.fromOffset(50, 25)
	sw.Position = UDim2.new(1, -61, 0.5, -12)
	sw.Text = ""
	sw.Parent = row
	corner(sw, 99)

	local knob = Instance.new("Frame")
	knob.Size = UDim2.fromOffset(19, 19)
	knob.BackgroundColor3 = Color3.fromRGB(245, 248, 255)
	knob.Parent = sw
	corner(knob, 99)

	local function update()
		local on = settings[key] == true
		label.Text = labelText .. " (" .. (on and "ON" or "OFF") .. ")"
		sw.BackgroundColor3 = on and Color3.fromRGB(0, 160, 235) or Color3.fromRGB(20, 49, 78)
		knob.Position = on and UDim2.new(1, -22, 0.5, -9) or UDim2.fromOffset(3, 3)
	end

	sw.Activated:Connect(function()
		settings[key] = not settings[key]
		update()
		if key == "AimbotCircle" then refreshCircle() end
	end)
	update()
end

local function makeSlider(labelText, key, minValue, maxValue)
	local row = rowBase(59)

	local label = Instance.new("TextLabel")
	label.Size = UDim2.new(1, -85, 0, 23)
	label.Position = UDim2.fromOffset(12, 2)
	label.BackgroundTransparency = 1
	label.Text = labelText
	label.TextColor3 = Color3.fromRGB(205, 220, 235)
	label.Font = Enum.Font.Gotham
	label.TextSize = 11
	label.TextXAlignment = Enum.TextXAlignment.Left
	label.Parent = row

	local valueLabel = Instance.new("TextLabel")
	valueLabel.Size = UDim2.fromOffset(55, 23)
	valueLabel.Position = UDim2.new(1, -67, 0, 2)
	valueLabel.BackgroundTransparency = 1
	valueLabel.TextColor3 = Color3.fromRGB(150, 195, 230)
	valueLabel.Font = Enum.Font.GothamBold
	valueLabel.TextSize = 11
	valueLabel.Parent = row

	local bar = Instance.new("Frame")
	bar.Size = UDim2.new(1, -24, 0, 6)
	bar.Position = UDim2.fromOffset(12, 40)
	bar.BackgroundColor3 = Color3.fromRGB(24, 51, 79)
	bar.BorderSizePixel = 0
	bar.Parent = row
	corner(bar, 99)

	local fill = Instance.new("Frame")
	fill.BackgroundColor3 = Color3.fromRGB(0, 150, 235)
	fill.BorderSizePixel = 0
	fill.Parent = bar
	corner(fill, 99)

	local knob = Instance.new("Frame")
	knob.Size = UDim2.fromOffset(12, 12)
	knob.AnchorPoint = Vector2.new(0.5, 0.5)
	knob.BackgroundColor3 = Color3.fromRGB(0, 210, 255)
	knob.Parent = bar
	corner(knob, 99)

	local draggingSlider = false

	local function setPercent(p)
		p = math.clamp(p, 0, 1)
		local v = math.floor(minValue + (maxValue - minValue) * p + 0.5)
		settings[key] = v
		valueLabel.Text = tostring(v)
		fill.Size = UDim2.new(p, 0, 1, 0)
		knob.Position = UDim2.new(p, 0, 0.5, 0)
		refreshCircle()
	end

	local function update()
		local v = math.clamp(tonumber(settings[key]) or minValue, minValue, maxValue)
		local p = (v - minValue) / (maxValue - minValue)
		settings[key] = v
		valueLabel.Text = tostring(v)
		fill.Size = UDim2.new(p, 0, 1, 0)
		knob.Position = UDim2.new(p, 0, 0.5, 0)
	end

	bar.InputBegan:Connect(function(input)
		if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
			draggingSlider = true
			setPercent((input.Position.X - bar.AbsolutePosition.X) / bar.AbsoluteSize.X)
		end
	end)
	UIS.InputChanged:Connect(function(input)
		if draggingSlider and (input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch) then
			setPercent((input.Position.X - bar.AbsolutePosition.X) / bar.AbsoluteSize.X)
		end
	end)
	UIS.InputEnded:Connect(function(input)
		if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
			draggingSlider = false
		end
	end)
	update()
end

local function makeDropdown(labelText, key, options)
	local row = rowBase(43)

	local label = Instance.new("TextLabel")
	label.Size = UDim2.new(1, -150, 1, 0)
	label.Position = UDim2.fromOffset(12, 0)
	label.BackgroundTransparency = 1
	label.Text = labelText
	label.TextColor3 = Color3.fromRGB(205, 220, 235)
	label.Font = Enum.Font.Gotham
	label.TextSize = 11
	label.TextXAlignment = Enum.TextXAlignment.Left
	label.Parent = row

	local b = Instance.new("TextButton")
	b.Size = UDim2.fromOffset(125, 29)
	b.Position = UDim2.new(1, -136, 0.5, -14)
	b.BackgroundColor3 = Color3.fromRGB(17, 47, 77)
	b.TextColor3 = Color3.fromRGB(155, 205, 235)
	b.Font = Enum.Font.GothamBold
	b.TextSize = 10
	b.Parent = row
	corner(b, 5)

	local index = table.find(options, settings[key]) or 1
	local function update() b.Text = tostring(settings[key]) end
	b.Activated:Connect(function()
		index = (index % #options) + 1
		settings[key] = options[index]
		update()
		refreshCircle()
	end)
	update()
end

local function showScripts()
	clear()
	makeToggle("Aimbot Circle", "AimbotCircle")
	makeToggle("Aimbot Shoot Button", "AimbotShootButton")
	makeToggle("Remove Teammate Target", "RemoveTeammateTarget")
	makeSlider("Circle Radius", "CircleRadius", 50, 300)
	makeDropdown("Circle Color", "CircleColor", {"Cyan Neon","White","Red","Green","Yellow"})
	makeDropdown("Camera Target", "CameraTarget", {"Head","HumanoidRootPart","UpperTorso"})
	makeSlider("Aim Smoothness", "SmoothnessPercent", 1, 30)
end

-- Keep SmoothnessPercent as a UI-only representation of the internal smoothness.
settings.SmoothnessPercent = math.clamp(math.floor((settings.Smoothness or 0.18) * 100), 1, 30)

local oldShowScripts = showScripts
showScripts = function()
	clear()
	makeToggle("Aimbot Circle", "AimbotCircle")
	makeToggle("Aimbot Shoot Button", "AimbotShootButton")
	makeToggle("Remove Teammate Target", "RemoveTeammateTarget")
	makeSlider("Circle Radius", "CircleRadius", 50, 300)
	makeDropdown("Circle Color", "CircleColor", {"Cyan Neon","White","Red","Green","Yellow"})
	makeDropdown("Camera Target", "CameraTarget", {"Head","HumanoidRootPart","UpperTorso"})
	makeSlider("Aim Smoothness", "SmoothnessPercent", 1, 30)
end

local function showSettings()
	clear()

	local info = Instance.new("TextLabel")
	info.Size = UDim2.new(1, -5, 0, 55)
	info.BackgroundTransparency = 1
	info.Text = "SETTINGS\nSave your current features. Saved values are restored when you rejoin."
	info.TextColor3 = Color3.fromRGB(155, 195, 225)
	info.Font = Enum.Font.Gotham
	info.TextSize = 11
	info.TextWrapped = true
	info.TextXAlignment = Enum.TextXAlignment.Left
	info.Parent = content

	local save = Instance.new("TextButton")
	save.Size = UDim2.new(1, -5, 0, 45)
	save.BackgroundColor3 = Color3.fromRGB(0, 75, 220)
	save.Text = "SAVE CHANGES"
	save.TextColor3 = Color3.fromRGB(225, 240, 255)
	save.Font = Enum.Font.GothamBold
	save.TextSize = 12
	save.Parent = content
	corner(save, 6)

	save.Activated:Connect(function()
		settings.Smoothness = math.clamp((settings.SmoothnessPercent or 18) / 100, 0.01, 0.30)
		saveRemote:FireServer(settings)
		save.Text = "CHANGES SAVED ✓"
		TweenService:Create(save, TweenInfo.new(0.15), {BackgroundColor3 = Color3.fromRGB(0, 150, 120)}):Play()
		task.delay(1.4, function()
			if save.Parent then
				save.Text = "SAVE CHANGES"
				save.BackgroundColor3 = Color3.fromRGB(0, 75, 220)
			end
		end)
	end)
end

local function showHistory()
	clear()
	local history = Instance.new("TextLabel")
	history.Size = UDim2.new(1, -5, 0, 150)
	history.BackgroundTransparency = 1
	history.Text = "HISTORY\n\n• Aim Assist Hub initialized\n• Saved settings loaded\n• Training-target mode active\n• Targets are limited to Workspace.TrainingTargets"
	history.TextColor3 = Color3.fromRGB(165, 200, 225)
	history.Font = Enum.Font.Gotham
	history.TextSize = 11
	history.TextWrapped = true
	history.TextXAlignment = Enum.TextXAlignment.Left
	history.TextYAlignment = Enum.TextYAlignment.Top
	history.Parent = content
end

scriptsTab.Activated:Connect(showScripts)
settingsTab.Activated:Connect(showSettings)
historyTab.Activated:Connect(showHistory)

-- Mobile-friendly open button
local openButton = Instance.new("TextButton")
openButton.Name = "OpenButton"
openButton.Size = UDim2.fromOffset(45, 45)
openButton.Position = UDim2.new(1, -60, 1, -65)
openButton.BackgroundColor3 = Color3.fromRGB(6, 32, 65)
openButton.Text = "≡"
openButton.TextColor3 = Color3.fromRGB(0, 200, 255)
openButton.Font = Enum.Font.GothamBold
openButton.TextSize = 22
openButton.Visible = false
openButton.Parent = gui
corner(openButton, 10)
stroke(openButton, Color3.fromRGB(0, 150, 255), 1)
openButton.Activated:Connect(function()
	main.Visible = true
	openButton.Visible = false
end)

close.Activated:Connect(function()
	main.Visible = false
	openButton.Visible = true
end)

UIS.InputBegan:Connect(function(input, processed)
	if processed then return end
	if input.KeyCode == Enum.KeyCode.RightShift then
		main.Visible = not main.Visible
		openButton.Visible = not main.Visible
	end
end)

-- Aim system: own-game training NPCs only.
local function getTargetPart(model)
	if not model:IsA("Model") then return nil end
	local hum = model:FindFirstChildOfClass("Humanoid")
	if not hum or hum.Health <= 0 then return nil end
	local p = model:FindFirstChild(settings.CameraTarget)
	if p and p:IsA("BasePart") then return p end
	local root = model:FindFirstChild("HumanoidRootPart")
	return root and root:IsA("BasePart") and root or nil
end

local function closestTarget()
	local folder = workspace:FindFirstChild("TrainingTargets")
	if not folder or not settings.AimbotCircle then return nil end

	local camera = workspace.CurrentCamera
	local viewport = camera.ViewportSize
	local center = Vector2.new(viewport.X / 2, viewport.Y / 2)
	local best, bestDistance = nil, math.huge

	for _, model in ipairs(folder:GetChildren()) do
		local part = getTargetPart(model)
		if part then
			local screen, visible = camera:WorldToViewportPoint(part.Position)
			if visible and screen.Z > 0 then
				local d = (Vector2.new(screen.X, screen.Y) - center).Magnitude
				if d <= settings.CircleRadius and d < bestDistance then
					bestDistance = d
					best = part
				end
			end
		end
	end
	return best
end

RunService.RenderStepped:Connect(function()
	if not settings.AimbotCircle then return end
	local target = closestTarget()
	if not target then return end

	local camera = workspace.CurrentCamera
	local desired = CFrame.lookAt(camera.CFrame.Position, target.Position)
	local smooth = math.clamp(settings.Smoothness or 0.18, 0.01, 0.30)
	camera.CFrame = camera.CFrame:Lerp(desired, smooth)
end)

showScripts()
refreshCircle()
