-- AimAssistHubServer.lua
-- Place in ServerScriptService as a Script.
-- DataStore persistence is for your own published Roblox experience.

local Players = game:GetService("Players")
local DataStoreService = game:GetService("DataStoreService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local store = DataStoreService:GetDataStore("AimAssistHubSettings_v3")

local remotes = ReplicatedStorage:FindFirstChild("AimAssistRemotes") or Instance.new("Folder")
remotes.Name = "AimAssistRemotes"
remotes.Parent = ReplicatedStorage

local saveRemote = remotes:FindFirstChild("SaveSettings") or Instance.new("RemoteEvent")
saveRemote.Name = "SaveSettings"
saveRemote.Parent = remotes

local loadRemote = remotes:FindFirstChild("LoadSettings") or Instance.new("RemoteFunction")
loadRemote.Name = "LoadSettings"
loadRemote.Parent = remotes

local DEFAULTS = {
	AimbotCircle = false,
	AimbotShootButton = false,
	RemoveTeammateTarget = true,
	CircleRadius = 100,
	CircleColor = "Cyan Neon",
	CameraTarget = "Head",
	Smoothness = 0.18,
}

local allowedColors = {
	["Cyan Neon"] = true, ["White"] = true, ["Red"] = true,
	["Green"] = true, ["Yellow"] = true,
}
local allowedTargets = {
	Head = true, HumanoidRootPart = true, UpperTorso = true,
}

local cache = {}

local function sanitize(data)
	data = type(data) == "table" and data or {}
	return {
		AimbotCircle = data.AimbotCircle == true,
		AimbotShootButton = data.AimbotShootButton == true,
		RemoveTeammateTarget = data.RemoveTeammateTarget ~= false,
		CircleRadius = math.clamp(math.floor(tonumber(data.CircleRadius) or 100), 50, 300),
		CircleColor = allowedColors[data.CircleColor] and data.CircleColor or DEFAULTS.CircleColor,
		CameraTarget = allowedTargets[data.CameraTarget] and data.CameraTarget or DEFAULTS.CameraTarget,
		Smoothness = math.clamp(tonumber(data.Smoothness) or DEFAULTS.Smoothness, 0.01, 0.30),
	}
end

local function loadPlayer(player)
	local result
	local ok, err = pcall(function()
		result = store:GetAsync("Player_" .. player.UserId)
	end)
	if ok and result then
		cache[player] = sanitize(result)
	else
		cache[player] = sanitize(DEFAULTS)
		if not ok then warn("[AimAssistHub] Load failed: " .. tostring(err)) end
	end
end

local function savePlayer(player)
	local data = cache[player]
	if not data then return end

	local ok, err = pcall(function()
		store:UpdateAsync("Player_" .. player.UserId, function()
			return sanitize(data)
		end)
	end)
	if not ok then warn("[AimAssistHub] Save failed: " .. tostring(err)) end
end

Players.PlayerAdded:Connect(loadPlayer)
Players.PlayerRemoving:Connect(function(player)
	savePlayer(player)
	cache[player] = nil
end)

loadRemote.OnServerInvoke = function(player)
	if not cache[player] then loadPlayer(player) end
	return sanitize(cache[player])
end

saveRemote.OnServerEvent:Connect(function(player, data)
	cache[player] = sanitize(data)
	savePlayer(player)
end)

game:BindToClose(function()
	for _, player in ipairs(Players:GetPlayers()) do
		savePlayer(player)
	end
end)
