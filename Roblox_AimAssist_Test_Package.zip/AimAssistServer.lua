-- AimAssistServer.lua
-- Put this Script in ServerScriptService.
-- For DataStore testing in Studio:
-- Game Settings > Security > Enable Studio Access to API Services
-- The experience must be published for DataStore persistence.

local Players = game:GetService("Players")
local DataStoreService = game:GetService("DataStoreService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local store = DataStoreService:GetDataStore("AimAssistSettings_v2")

local remotes = ReplicatedStorage:FindFirstChild("AimAssistRemotes")
if not remotes then
	remotes = Instance.new("Folder")
	remotes.Name = "AimAssistRemotes"
	remotes.Parent = ReplicatedStorage
end

local saveEvent = remotes:FindFirstChild("SaveSettings")
if not saveEvent then
	saveEvent = Instance.new("RemoteEvent")
	saveEvent.Name = "SaveSettings"
	saveEvent.Parent = remotes
end

local loadFunction = remotes:FindFirstChild("LoadSettings")
if not loadFunction then
	loadFunction = Instance.new("RemoteFunction")
	loadFunction.Name = "LoadSettings"
	loadFunction.Parent = remotes
end

local DEFAULTS = {
	AimbotCircle = false,
	AimbotShootButton = false,
	RemoveTeammateTarget = true,
	CircleRadius = 100,
	CircleColor = "Cyan Neon",
	CameraTarget = "Head",
}

local COLORS = {
	["Cyan Neon"] = true,
	["White"] = true,
	["Red"] = true,
	["Green"] = true,
	["Yellow"] = true,
}

local TARGETS = {
	Head = true,
	HumanoidRootPart = true,
	UpperTorso = true,
}

local cache = {}

local function sanitize(data)
	if type(data) ~= "table" then
		data = {}
	end

	return {
		AimbotCircle = data.AimbotCircle == true,
		AimbotShootButton = data.AimbotShootButton == true,
		RemoveTeammateTarget = data.RemoveTeammateTarget ~= false,
		CircleRadius = math.clamp(math.floor(tonumber(data.CircleRadius) or 100), 50, 300),
		CircleColor = COLORS[data.CircleColor] and data.CircleColor or DEFAULTS.CircleColor,
		CameraTarget = TARGETS[data.CameraTarget] and data.CameraTarget or DEFAULTS.CameraTarget,
	}
end

local function loadPlayer(player)
	local data = DEFAULTS

	local ok, result = pcall(function()
		return store:GetAsync("Player_" .. player.UserId)
	end)

	if ok and result then
		data = sanitize(result)
	elseif not ok then
		warn("[AimAssist] DataStore load failed for " .. player.Name .. ": " .. tostring(result))
	end

	cache[player] = data
end

local function savePlayer(player)
	local data = cache[player]
	if not data then
		return
	end

	local ok, err = pcall(function()
		store:SetAsync("Player_" .. player.UserId, sanitize(data))
	end)

	if not ok then
		warn("[AimAssist] DataStore save failed for " .. player.Name .. ": " .. tostring(err))
	end
end

Players.PlayerAdded:Connect(loadPlayer)

Players.PlayerRemoving:Connect(function(player)
	savePlayer(player)
	cache[player] = nil
end)

loadFunction.OnServerInvoke = function(player)
	if not cache[player] then
		loadPlayer(player)
	end
	return sanitize(cache[player])
end

saveEvent.OnServerEvent:Connect(function(player, settings)
	if type(settings) ~= "table" then
		return
	end

	cache[player] = sanitize(settings)
	savePlayer(player)
end)

game:BindToClose(function()
	for _, player in ipairs(Players:GetPlayers()) do
		savePlayer(player)
	end
end)
