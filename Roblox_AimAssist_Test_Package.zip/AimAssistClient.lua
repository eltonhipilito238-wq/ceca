-- AimAssistClient.lua
-- Put this LocalScript in StarterPlayer > StarterPlayerScripts.
-- TESTING ONLY: targets are restricted to Workspace.TrainingTargets.

local Players = game:GetService("Players")
local UserInputService = game:GetService("UserInputService")
local RunService = game:GetService("RunService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local player = Players.LocalPlayer

local remotes = ReplicatedStorage:WaitForChild("AimAssistRemotes")
local saveEvent = remotes:WaitForChild("SaveSettings")
local loadFunction = remotes:WaitForChild("LoadSettings")

local DEFAULTS = {
	AimbotCircle = false,
	AimbotShootButton = false,
	RemoveTeammateTarget = true,
	CircleRadius = 100,
	CircleColor = "Cyan Neon",
	CameraTarget = "Head",
}

local Settings = table.clone(DEFAULTS)

-- Load saved settings from the server.
local ok, saved = pcall(function()
	return loadFunction:InvokeServer()
end)

if ok and type(saved) == "table" then
	for key, value in pairs(DEFAULTS) do
		if saved[key] ~= nil then
			Settings[key] = saved[key]
		end
	end
end

local COLORS = {
	["Cyan Neon"] = Color3.fromRGB(0, 255, 255),
	["White"] = Color3.fromRGB(255, 255, 255),
	["Red"] = Color3.fromRGB(255, 70, 70),
	["Green"] = Color3.fromRGB(80, 255, 100),
	["Yellow"] = Color3.fromRGB(255, 240, 70),
}

local gui = Instance.new("ScreenGui")
gui.Name = "AimAssistHub"
gui.ResetOnSpawn = false
gui.IgnoreGuiInset = true
gui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
gui.Parent = player:WaitForChild("PlayerGui")

local main = Instance.new("Frame")
main.Name = "Main"
main.Size = UDim2.fromOffset(465, 365)
main.Position = UDim2.new(1, -490, 0.5, -182)
main.BackgroundColor3 = Color3.fromRGB(9, 25, 48)
main.BorderSizePixel = 0
main.Parent = gui

Instance.new("UICorner", main).CornerRadius = UDim.new(0, 10)
local mainStroke = Instance.new("UIStroke", main)
mainStroke.Color = Color3.fromRGB(0, 170, 255)
mainStroke.Thickness = 2

local title = Instance.new("TextLabel")
title.Size = UDim2.new(1, -55, 0, 45)
title.Position = UDim2.fromOffset(15, 5)
title.BackgroundTransparency = 1
title.Text = "AFNANSAKHA HUB"
title.TextColor3 = Color3.fromRGB(0, 190, 255)
title.Font = Enum.Font.GothamBold
title.TextSize = 18
title.TextXAlignment = Enum.TextXAlignment.Left
title.Parent = main

local closeButton = Instance.new("TextButton")
closeButton.Size = UDim2.fromOffset(35, 35)
closeButton.Position = UDim2.new(1, -42, 0, 5)
closeButton.BackgroundTransparency = 1
closeButton.Text = "X"
closeButton.TextColor3 = Color3.fromRGB(0, 170, 255)
closeButton.Font = Enum.Font.GothamBold
closeButton.TextSize = 18
closeButton.Parent = main

local tabs = Instance.new("Frame")
tabs.Size = UDim2.new(1, -20, 0, 40)
tabs.Position = UDim2.fromOffset(10, 48)
tabs.BackgroundTransparency = 1
tabs.Parent = main

local function makeTab(name, x)
	local b = Instance.new("TextButton")
	b.Size = UDim2.new(1/3, -5, 1, 0)
	b.Position = UDim2.new(x, 0, 0, 0)
	b.BackgroundColor3 = Color3.fromRGB(12, 37, 68)
	b.BorderSizePixel = 0
	b.Text = name:upper()
	b.TextColor3 = Color3.fromRGB(180, 210, 235)
	b.Font = Enum.Font.GothamBold
	b.TextSize = 11
	b.Parent = tabs
	Instance.new("UICorner", b).CornerRadius = UDim.new(0, 5)
	return b
end

local scriptsTab = makeTab("Scripts", 0)
local settingsTab = makeTab("Settings", 1/3)
local historyTab = makeTab("History", 2/3)

local content = Instance.new("ScrollingFrame")
content.Size = UDim2.new(1, -20, 1, -145)
content.Position = UDim2.fromOffset(10, 95)
content.BackgroundTransparency = 1
content.BorderSizePixel = 0
content.ScrollBarThickness = 4
content.AutomaticCanvasSize = Enum.AutomaticSize.Y
content.CanvasSize = UDim2.new()
content.Parent = main

local layout = Instance.new("UIListLayout", content)
layout.Padding = UDim.new(0, 6)

local circle = Instance.new("Frame")
circle.Name = "AimCircle"
circle.AnchorPoint = Vector2.new(0.5, 0.5)
circle.Position = UDim2.fromScale(0.5, 0.5)
circle.BackgroundTransparency = 1
circle.Visible = false
circle.Parent = gui
Instance.new("UICorner", circle).CornerRadius = UDim.new(1, 0)
local circleStroke = Instance.new("UIStroke", circle)
circleStroke.Thickness = 2
circleStroke.Transparency = 0.1

local function refreshCircle()
	circle.Size = UDim2.fromOffset(Settings.CircleRadius * 2, Settings.CircleRadius * 2)
	circleStroke.Color = COLORS[Settings.CircleColor] or COLORS["Cyan Neon"]
	circle.Visible = Settings.AimbotCircle
end

local function clearContent()
	for _, child in ipairs(content:GetChildren()) do
		if child ~= layout then
			child:Destroy()
		end
	end
end

local function createToggle(text, key)
	local holder = Instance.new("Frame")
	holder.Size = UDim2.new(1, -5, 0, 43)
	holder.BackgroundColor3 = Color3.fromRGB(12, 34, 62)
	holder.BorderSizePixel = 0
	holder.Parent = content
	Instance.new("UICorner", holder).CornerRadius = UDim.new(0, 6)

	local label = Instance.new("TextLabel")
	label.Size = UDim2.new(1, -75, 1, 0)
	label.Position = UDim2.fromOffset(12, 0)
	label.BackgroundTransparency = 1
	label.TextColor3 = Color3.fromRGB(210, 220, 235)
	label.Font = Enum.Font.Gotham
	label.TextSize = 12
	label.TextXAlignment = Enum.TextXAlignment.Left
	label.Parent = holder

	local button = Instance.new("TextButton")
	button.Size = UDim2.fromOffset(50, 25)
	button.Position = UDim2.new(1, -60, 0.5, -12)
	button.Text = ""
	button.Parent = holder
	Instance.new("UICorner", button).CornerRadius = UDim.new(1, 0)

	local dot = Instance.new("Frame")
	dot.Size = UDim2.fromOffset(19, 19)
	dot.BackgroundColor3 = Color3.fromRGB(245, 245, 245)
	dot.Parent = button
	Instance.new("UICorner", dot).CornerRadius = UDim.new(1, 0)

	local function update()
		local on = Settings[key] == true
		label.Text = text .. " (" .. (on and "ON" or "OFF") .. ")"
		button.BackgroundColor3 = on and Color3.fromRGB(0, 170, 255) or Color3.fromRGB(22, 49, 78)
		dot.Position = on and UDim2.new(1, -22, 0.5, -9) or UDim2.fromOffset(3, 3)
	end

	button.Activated:Connect(function()
		Settings[key] = not Settings[key]
		update()
		if key == "AimbotCircle" then
			refreshCircle()
		end
	end)

	update()
end

local function createSlider(text, key, min, max)
	local holder = Instance.new("Frame")
	holder.Size = UDim2.new(1, -5, 0, 60)
	holder.BackgroundColor3 = Color3.fromRGB(12, 34, 62)
	holder.BorderSizePixel = 0
	holder.Parent = content
	Instance.new("UICorner", holder).CornerRadius = UDim.new(0, 6)

	local label = Instance.new("TextLabel")
	label.Size = UDim2.new(1, -80, 0, 25)
	label.Position = UDim2.fromOffset(12, 3)
	label.BackgroundTransparency = 1
	label.Text = text
	label.TextColor3 = Color3.fromRGB(210, 220, 235)
	label.Font = Enum.Font.Gotham
	label.TextSize = 12
	label.TextXAlignment = Enum.TextXAlignment.Left
	label.Parent = holder

	local valueLabel = Instance.new("TextLabel")
	valueLabel.Size = UDim2.fromOffset(55, 25)
	valueLabel.Position = UDim2.new(1, -65, 0, 3)
	valueLabel.BackgroundTransparency = 1
	valueLabel.TextColor3 = Color3.fromRGB(150, 190, 225)
	valueLabel.Font = Enum.Font.GothamBold
	valueLabel.TextSize = 12
	valueLabel.Parent = holder

	local bar = Instance.new("Frame")
	bar.Size = UDim2.new(1, -24, 0, 6)
	bar.Position = UDim2.fromOffset(12, 39)
	bar.BackgroundColor3 = Color3.fromRGB(26, 53, 82)
	bar.BorderSizePixel = 0
	bar.Parent = holder
	Instance.new("UICorner", bar).CornerRadius = UDim.new(1, 0)

	local knob = Instance.new("Frame")
	knob.Size = UDim2.fromOffset(12, 12)
	knob.AnchorPoint = Vector2.new(0.5, 0.5)
	knob.BackgroundColor3 = Color3.fromRGB(0, 190, 255)
	knob.Parent = bar
	Instance.new("UICorner", knob).CornerRadius = UDim.new(1, 0)

	local dragging = false

	local function setFromX(x)
		local percent = math.clamp((x - bar.AbsolutePosition.X) / bar.AbsoluteSize.X, 0, 1)
		local newValue = math.floor(min + (max - min) * percent + 0.5)
		Settings[key] = newValue
		valueLabel.Text = tostring(newValue)
		knob.Position = UDim2.new(percent, 0, 0.5, 0)
		refreshCircle()
	end

	local function update()
		local value = math.clamp(tonumber(Settings[key]) or min, min, max)
		Settings[key] = value
		local percent = (value - min) / (max - min)
		valueLabel.Text = tostring(value)
		knob.Position = UDim2.new(percent, 0, 0.5, 0)
	end

	bar.InputBegan:Connect(function(input)
		if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
			dragging = true
			setFromX(input.Position.X)
		end
	end)

	UserInputService.InputChanged:Connect(function(input)
		if dragging and (input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch) then
			setFromX(input.Position.X)
		end
	end)

	UserInputService.InputEnded:Connect(function(input)
		if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
			dragging = false
		end
	end)

	update()
end

local function createDropdown(text, key, options)
	local holder = Instance.new("Frame")
	holder.Size = UDim2.new(1, -5, 0, 45)
	holder.BackgroundColor3 = Color3.fromRGB(12, 34, 62)
	holder.BorderSizePixel = 0
	holder.Parent = content
	Instance.new("UICorner", holder).CornerRadius = UDim.new(0, 6)

	local label = Instance.new("TextLabel")
	label.Size = UDim2.new(1, -145, 1, 0)
	label.Position = UDim2.fromOffset(12, 0)
	label.BackgroundTransparency = 1
	label.Text = text
	label.TextColor3 = Color3.fromRGB(210, 220, 235)
	label.Font = Enum.Font.Gotham
	label.TextSize = 12
	label.TextXAlignment = Enum.TextXAlignment.Left
	label.Parent = holder

	local button = Instance.new("TextButton")
	button.Size = UDim2.fromOffset(120, 30)
	button.Position = UDim2.new(1, -130, 0.5, -15)
	button.BackgroundColor3 = Color3.fromRGB(22, 49, 78)
	button.TextColor3 = Color3.fromRGB(150, 210, 240)
	button.Font = Enum.Font.GothamBold
	button.TextSize = 10
	button.Parent = holder
	Instance.new("UICorner", button).CornerRadius = UDim.new(0, 5)

	local index = table.find(options, Settings[key]) or 1
	local function update()
		button.Text = tostring(Settings[key])
	end
	button.Activated:Connect(function()
		index = (index % #options) + 1
		Settings[key] = options[index]
		update()
		if key == "CircleColor" then refreshCircle() end
	end)
	update()
end

local function showScripts()
	clearContent()
	createToggle("Aimbot Circle", "AimbotCircle")
	createToggle("Aimbot Shoot Button", "AimbotShootButton")
	createToggle("Remove Teammate Target", "RemoveTeammateTarget")
	createSlider("Circle Radius", "CircleRadius", 50, 300)
	createDropdown("Circle Color", "CircleColor", {"Cyan Neon", "White", "Red", "Green", "Yellow"})
	createDropdown("Camera Target", "CameraTarget", {"Head", "HumanoidRootPart", "UpperTorso"})
	refreshCircle()
end

local function showSettings()
	clearContent()

	local info = Instance.new("TextLabel")
	info.Size = UDim2.new(1, -5, 0, 55)
	info.BackgroundTransparency = 1
	info.Text = "Save your current configuration to your Roblox account.\nThe settings will be loaded when you rejoin."
	info.TextColor3 = Color3.fromRGB(160, 190, 220)
	info.Font = Enum.Font.Gotham
	info.TextSize = 11
	info.TextWrapped = true
	info.Parent = content

	local saveButton = Instance.new("TextButton")
	saveButton.Size = UDim2.new(1, -5, 0, 45)
	saveButton.BackgroundColor3 = Color3.fromRGB(0, 92, 220)
	saveButton.BorderSizePixel = 0
	saveButton.Text = "SAVE CHANGES"
	saveButton.TextColor3 = Color3.new(1, 1, 1)
	saveButton.Font = Enum.Font.GothamBold
	saveButton.TextSize = 12
	saveButton.Parent = content
	Instance.new("UICorner", saveButton).CornerRadius = UDim.new(0, 6)

	saveButton.Activated:Connect(function()
		saveEvent:FireServer(Settings)
		saveButton.Text = "SAVED!"
		task.delay(1.5, function()
			if saveButton.Parent then
				saveButton.Text = "SAVE CHANGES"
			end
		end)
	end)
end

local function showHistory()
	clearContent()

	local label = Instance.new("TextLabel")
	label.Size = UDim2.new(1, -5, 0, 120)
	label.BackgroundTransparency = 1
	label.Text = "History\n\n• Aim Assist initialized\n• Saved configuration loaded\n• Training-target mode enabled"
	label.TextColor3 = Color3.fromRGB(170, 200, 225)
	label.Font = Enum.Font.Gotham
	label.TextSize = 12
	label.TextWrapped = true
	label.TextXAlignment = Enum.TextXAlignment.Left
	label.TextYAlignment = Enum.TextYAlignment.Top
	label.Parent = content
end

scriptsTab.Activated:Connect(showScripts)
settingsTab.Activated:Connect(showSettings)
historyTab.Activated:Connect(showHistory)

closeButton.Activated:Connect(function()
	main.Visible = false
end)

-- RightShift toggles the desktop UI.
-- On mobile, use the close/open controls or adapt this to your own button.
UserInputService.InputBegan:Connect(function(input, processed)
	if processed then return end
	if input.KeyCode == Enum.KeyCode.RightShift then
		main.Visible = not main.Visible
	end
end)

-- ============================
-- TRAINING TARGET AIM SYSTEM
-- ============================

local function getTargetPart(model)
	if not model:IsA("Model") then return nil end

	local humanoid = model:FindFirstChildOfClass("Humanoid")
	if not humanoid or humanoid.Health <= 0 then return nil end

	local part = model:FindFirstChild(Settings.CameraTarget)
	if part and part:IsA("BasePart") then
		return part
	end

	local fallback = model:FindFirstChild("HumanoidRootPart")
	return fallback and fallback:IsA("BasePart") and fallback or nil
end

local function findClosestTarget()
	if not Settings.AimbotCircle then return nil end

	local camera = workspace.CurrentCamera
	if not camera then return nil end

	local folder = workspace:FindFirstChild("TrainingTargets")
	if not folder then return nil end

	local viewport = camera.ViewportSize
	local center = Vector2.new(viewport.X / 2, viewport.Y / 2)

	local bestPart
	local bestDistance = math.huge

	for _, model in ipairs(folder:GetChildren()) do
		local part = getTargetPart(model)

		if part then
			local screen, visible = camera:WorldToViewportPoint(part.Position)
			if visible and screen.Z > 0 then
				local distance = (Vector2.new(screen.X, screen.Y) - center).Magnitude
				if distance <= Settings.CircleRadius and distance < bestDistance then
					bestDistance = distance
					bestPart = part
				end
			end
		end
	end

	return bestPart
end

RunService.RenderStepped:Connect(function()
	if not Settings.AimbotCircle then return end

	local target = findClosestTarget()
	if not target then return end

	local camera = workspace.CurrentCamera
	local origin = camera.CFrame.Position
	local desired = CFrame.lookAt(origin, target.Position)

	camera.CFrame = camera.CFrame:Lerp(desired, 0.18)
end)

showScripts()
refreshCircle()
