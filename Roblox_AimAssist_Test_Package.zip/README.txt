ROBLOX AIM ASSIST TEST PACKAGE
===============================

This package is designed for YOUR OWN Roblox experience/testing environment.

FILES
-----
1. AimAssistServer.lua
   Put in ServerScriptService.

2. AimAssistClient.lua
   Put in StarterPlayer > StarterPlayerScripts.

3. README.txt
   This setup guide.

TRAINING TARGETS
----------------
Create a Folder in Workspace named:

TrainingTargets

Put your NPC/dummy Models inside it. Each target should have:
- Humanoid
- HumanoidRootPart
- Head (recommended)

The aim system ONLY searches this folder.

SETUP
-----
1. Open your Roblox Studio place.
2. Create Workspace > Folder named TrainingTargets.
3. Put one or more NPC dummies inside it.
4. Insert AimAssistServer.lua into ServerScriptService as a Script.
5. Insert AimAssistClient.lua into StarterPlayer > StarterPlayerScripts as a LocalScript.
6. Publish the experience.
7. For DataStore testing in Studio, enable:
   Game Settings > Security > Enable Studio Access to API Services.
8. Press Play.

CONTROLS
--------
RightShift = show/hide the UI on desktop.

The UI includes:
- Scripts
- Settings
- History
- Aimbot Circle
- Aimbot Shoot Button toggle
- Remove Teammate Target toggle
- Circle Radius
- Circle Color
- Camera Target
- Save Changes

IMPORTANT
---------
The "Aimbot Shoot Button" option is a UI setting only in this package.
It is not connected to a weapon firing system because your weapon implementation
may use different RemoteEvents or Tool logic.

The aim system is intentionally restricted to Workspace.TrainingTargets.
It is not an exploit/executor script for other Roblox experiences.

DATASTORE
---------
Save Changes sends the current settings to the server.
The server sanitizes and stores them using DataStoreService.
When the player rejoins, their settings are loaded automatically.

If Studio cannot save:
- Publish the experience.
- Enable Studio Access to API Services.
- Check the Output window for DataStore warnings.
